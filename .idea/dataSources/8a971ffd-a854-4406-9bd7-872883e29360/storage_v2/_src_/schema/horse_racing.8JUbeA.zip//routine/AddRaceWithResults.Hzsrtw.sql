create
    definer = root@localhost procedure AddRaceWithResults(IN p_race_id varchar(15), IN p_race_name varchar(30),
                                                          IN p_track_name varchar(30), IN p_race_date date,
                                                          IN p_race_time time, IN p_horse_id varchar(15),
                                                          IN p_results varchar(15), IN p_prize decimal(10, 2))
BEGIN
    INSERT INTO Race (raceId, raceName, trackName, raceDate, raceTime)
    VALUES (p_race_id, p_race_name, p_track_name, p_race_date, p_race_time);

    INSERT INTO RaceResults (raceId, horseId, results, prize)
    VALUES (p_race_id, p_horse_id, p_results, p_prize);
END;

