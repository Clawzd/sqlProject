create
    definer = root@localhost procedure GetTrainerWinnings()
BEGIN
    SELECT t.fname, t.lname, SUM(rr.prize) as total_winnings
    FROM Trainer t
             JOIN Horse h ON t.stableId = h.stableId
             JOIN RaceResults rr ON h.horseId = rr.horseId
    GROUP BY t.trainerId, t.fname, t.lname
    ORDER BY total_winnings DESC;
END;

