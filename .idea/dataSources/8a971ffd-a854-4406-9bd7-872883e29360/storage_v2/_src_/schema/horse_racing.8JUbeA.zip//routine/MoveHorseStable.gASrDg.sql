create
    definer = root@localhost procedure MoveHorseStable(IN p_horse_id varchar(15), IN p_new_stable_id varchar(15))
BEGIN
    UPDATE Horse SET stableId = p_new_stable_id WHERE horseId = p_horse_id;
END;

