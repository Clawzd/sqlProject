create
    definer = root@localhost procedure GetWinningTrainers()
BEGIN
    SELECT t.fname, t.lname, h.horseName, r.raceName, rr.prize
    FROM Trainer t
             JOIN Horse h ON t.stableId = h.stableId
             JOIN RaceResults rr ON h.horseId = rr.horseId
             JOIN Race r ON rr.raceId = r.raceId
    WHERE rr.results = 'first';
END;

