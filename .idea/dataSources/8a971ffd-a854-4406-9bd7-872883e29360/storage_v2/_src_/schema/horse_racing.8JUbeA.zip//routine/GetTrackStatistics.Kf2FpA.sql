create
    definer = root@localhost procedure GetTrackStatistics()
BEGIN
    SELECT r.trackName,
           COUNT(DISTINCT r.raceId) as race_count,
           COUNT(DISTINCT rr.horseId) as horse_count
    FROM Race r
             JOIN RaceResults rr ON r.raceId = rr.raceId
    GROUP BY r.trackName;
END;

