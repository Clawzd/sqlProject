create
    definer = root@localhost procedure DeleteOwner(IN p_owner_id varchar(15))
BEGIN
    DELETE FROM Owns WHERE ownerId = p_owner_id;
    DELETE FROM Owner WHERE ownerId = p_owner_id;
END;

