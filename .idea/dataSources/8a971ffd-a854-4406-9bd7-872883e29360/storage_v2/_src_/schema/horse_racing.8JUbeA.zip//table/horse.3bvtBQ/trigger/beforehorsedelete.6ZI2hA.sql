create definer = root@localhost trigger BeforeHorseDelete
    before delete
    on horse
    for each row
    INSERT INTO old_horse_info
    (horseId, horseName, age, gender, registration, stableId)
    VALUES
        (OLD.horseId, OLD.horseName, OLD.age, OLD.gender, OLD.registration, OLD.stableId);

