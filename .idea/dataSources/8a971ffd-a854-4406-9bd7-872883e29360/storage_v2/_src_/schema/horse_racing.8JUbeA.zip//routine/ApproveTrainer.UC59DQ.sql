create
    definer = root@localhost procedure ApproveTrainer(IN p_trainer_id varchar(15), IN p_last_name varchar(30),
                                                      IN p_first_name varchar(30), IN p_stable_id varchar(30))
BEGIN
    INSERT INTO Trainer (trainerId, lname, fname, stableId)
    VALUES (p_trainer_id, p_last_name, p_first_name, p_stable_id);
END;

