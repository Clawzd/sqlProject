create
    definer = root@localhost procedure GetHorsesByOwnerLastName(IN owner_last_name varchar(15))
BEGIN
    SELECT h.horseName, h.age, t.fname, t.lname
    FROM Horse h
             JOIN Owns o ON h.horseId = o.horseId
             JOIN Owner ow ON o.ownerId = ow.ownerId
             JOIN Trainer t ON h.stableId = t.stableId
    WHERE ow.lname = owner_last_name;
END;

